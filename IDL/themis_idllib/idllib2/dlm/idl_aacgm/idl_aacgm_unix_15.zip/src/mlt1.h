/* mlt1.h
   ======
   Author: R.J.Barnes
*/

double mlt1(int t0,double solar_dec,double mlon,double *mslon);

