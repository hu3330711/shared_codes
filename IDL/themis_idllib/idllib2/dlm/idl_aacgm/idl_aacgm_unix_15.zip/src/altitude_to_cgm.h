/* altitude_to_cgm.h
   =================
   Author: R.J.Barnes
*/

void altitude_to_cgm(double,double,double *);
   
  
