/* mlt.h
   =====
   Author: R.J.Barnes
*/

double mlt(int yr,int t0,double mlong, double *mslong);




