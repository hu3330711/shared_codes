/* rylm.h
   ======
   Author: R.J.Barnes
*/

int rylm(double colat,double lon,int order,
	  double *ylmval);
   
  
