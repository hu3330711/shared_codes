/* eqn_of_time.h
   =============
   Author: R.J.Barnes
*/

double eqn_of_time(double mean_lon,int yr);

  
