/* cgm_to_altitude.h
   =================
   Author: R.J.Barnes
*/

int cgm_to_altitude(double,double,double *);
    
